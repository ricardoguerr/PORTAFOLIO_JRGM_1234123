﻿internal class Program
{
    private static void Main(string[] args)
    {
        int a, b;
        double n1, n2, n3;
  
        Console.Write("Ingrese un número: ");
        a = int.Parse(Console.ReadLine());
        Console.Write("Ingrese un número : ");
        b = int.Parse(Console.ReadLine());
        Console.WriteLine("\n------ OPERACIONES ARITEMETICAS ------");
        int suma = a + b;
        Console.WriteLine(a + "+" + b + " = " + suma);
        int resta = a - b;
        Console.WriteLine(a +"-" + b + " = " + resta);
        int mult = a * b;
        Console.WriteLine(a + "*" + b + " = " + mult);
        double div = a / b;
        Console.WriteLine(a + "/" + b + " = " + div);

        if(a > b)
        {
            Console.WriteLine("El número mayor es: " + a);
        }
        else
        {
            Console.WriteLine("El número mayor es: " + b);
        }
        if (a < b)
        {
            Console.WriteLine("El número menor es: " + a);
        }
        else
        {
            Console.WriteLine("El número menor es: " + b);
        }
        if(a == b)
        {
            Console.WriteLine("Los numeros a y b son iguales.");
        }
        else
        {
            Console.WriteLine("Los numeros a y b son diferentes.");
        }

        Console.WriteLine("----- EJ 3 JERARQUÍA DE OPERACIONES ------");
        Console.WriteLine("ingrese el valor para n1: ");
        n1 = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Ingrese el valor para n2: ");
        n2 = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Ingrese el valor para n3: ");
        n3 = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("\n" + n1 + "*" + n3 + "+" + n3 + " = " + ((n1 * n3)+n2));
        Console.WriteLine(n1 + "(" + n2 + "+" + n3 + ") = " + n1*(n2 + n3));
        Console.WriteLine(n1 + "/" + n2 + "*" + n3 + " = " + n1 / (n2 * n3));

    }
}