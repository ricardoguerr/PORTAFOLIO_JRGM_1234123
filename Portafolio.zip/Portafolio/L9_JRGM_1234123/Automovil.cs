﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L9_JRGM_1234123
{
    public class Automovil
    {
        private int modelo;
        private double precio, tipoCambioDolar, descuentoAplicado;
        private string marca;
        private bool disponible;

        public int Modelo
        {
            get;

        }

        public double Precio
        {
            get;
        }
        public double TipoCambioDolar
        {
            get;
        }
        public double DescuentoAplicado
        {
            get;
            set;
        }
        public string Marca
        {
            get;
            set;
        }
        public bool Disponible
        {
            get;
            set;
        }

        public Automovil()
        {
            modelo = 2019;
            precio = 10000.00;
            marca = "";
            disponible = false;
            tipoCambioDolar = 7.50;
            DescuentoAplicado = 0;

        }
        /*PROCEDIMIENTOS Y FUNCIONES*/
        public void definirModelo(int unModelo)
        {
            modelo = unModelo;
        }
        public void definirPrecio(double unPrecio)
        {
            precio = unPrecio;
        }
        public void definirMarca(string unaMarca)
        {
            marca = unaMarca;
        }
        public void definirTipoCambio(double unTipoDeCambio)
        {
            tipoCambioDolar = unTipoDeCambio;
        }
        public void CambiarDisponibilidad()
        {
            if (Disponible == true)
            {
                Disponible = false;
            }
            else
            {
                Disponible = true;
            }
        }
        public string MostrarDisponibilidad()
        {
            if (Disponible == true)
            {
                return "Disponible";
            }
            else
            {
                return "No se encuentra disponible actualmente.";
            }
        }
        private double PrecioDolares()
        {
            return precio * TipoCambioDolar;
        }

        public string MostrarInformación()
        {
            return $"Marca:{marca}.\nModelo: {modelo}.\nPrecio de venta: Q{precio}.\nPrecio en dolares: ${PrecioDolares()}.\nDisponibilidad: {MostrarDisponibilidad()}";
            
        }

        public void AplicarDescuento(double miDescuento)
        {
            DescuentoAplicado = miDescuento;
            double nuevoPrecio = precio - DescuentoAplicado;
            definirPrecio(nuevoPrecio);
        }
    }
}
