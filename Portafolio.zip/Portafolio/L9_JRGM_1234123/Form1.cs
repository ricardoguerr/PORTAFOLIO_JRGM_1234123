﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace L9_JRGM_1234123
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Automovil myAutomovil = new Automovil();

        private void btGuardarInfo_Click(object sender, EventArgs e)
        {//Obtenemos lo que esta en la caja y lo guardamos en la clase

            myAutomovil.definirModelo (Convert.ToInt32(txtModelo.Text));
            myAutomovil.definirPrecio (Convert.ToDouble(txtPrecio.Text));
            myAutomovil.definirMarca(txtMarca.Text);
            myAutomovil.definirTipoCambio(Convert.ToDouble(txtCambio.Text));
            textBox1.Text = myAutomovil.MostrarInformación();

            MessageBox.Show("Los datos fueron guardados exitosamente");
        }

        private void btLimpiar_Click(object sender, EventArgs e)
        {
            txtModelo.Clear();
            txtPrecio.Clear();
            txtPrecio.Clear();
            txtMarca.Clear();
        }

        private void btSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }
    }
}
