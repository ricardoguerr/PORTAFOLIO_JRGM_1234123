﻿namespace L9_JRGM_1234123
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbTitulo = new System.Windows.Forms.Label();
            this.tb1 = new System.Windows.Forms.TabControl();
            this.tbpIngresoDatos = new System.Windows.Forms.TabPage();
            this.txtCambio = new System.Windows.Forms.TextBox();
            this.txtMarca = new System.Windows.Forms.TextBox();
            this.txtPrecio = new System.Windows.Forms.TextBox();
            this.txtModelo = new System.Windows.Forms.TextBox();
            this.btGuardarInfo = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tbpDatosAuto = new System.Windows.Forms.TabPage();
            this.btCambiarDisp = new System.Windows.Forms.Button();
            this.btAplicar = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.txtDescuento = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.btLimpiar = new System.Windows.Forms.Button();
            this.btSalir = new System.Windows.Forms.Button();
            this.tb1.SuspendLayout();
            this.tbpIngresoDatos.SuspendLayout();
            this.tbpDatosAuto.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbTitulo
            // 
            this.lbTitulo.AutoSize = true;
            this.lbTitulo.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTitulo.Location = new System.Drawing.Point(348, 24);
            this.lbTitulo.Name = "lbTitulo";
            this.lbTitulo.Size = new System.Drawing.Size(181, 27);
            this.lbTitulo.TabIndex = 0;
            this.lbTitulo.Text = "LABORATORIO 9";
            // 
            // tb1
            // 
            this.tb1.Controls.Add(this.tbpIngresoDatos);
            this.tb1.Controls.Add(this.tbpDatosAuto);
            this.tb1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.tb1.Location = new System.Drawing.Point(158, 78);
            this.tb1.Name = "tb1";
            this.tb1.SelectedIndex = 0;
            this.tb1.Size = new System.Drawing.Size(486, 407);
            this.tb1.TabIndex = 1;
            // 
            // tbpIngresoDatos
            // 
            this.tbpIngresoDatos.Controls.Add(this.txtCambio);
            this.tbpIngresoDatos.Controls.Add(this.txtMarca);
            this.tbpIngresoDatos.Controls.Add(this.txtPrecio);
            this.tbpIngresoDatos.Controls.Add(this.txtModelo);
            this.tbpIngresoDatos.Controls.Add(this.btGuardarInfo);
            this.tbpIngresoDatos.Controls.Add(this.label4);
            this.tbpIngresoDatos.Controls.Add(this.label3);
            this.tbpIngresoDatos.Controls.Add(this.label2);
            this.tbpIngresoDatos.Controls.Add(this.label1);
            this.tbpIngresoDatos.Location = new System.Drawing.Point(4, 26);
            this.tbpIngresoDatos.Name = "tbpIngresoDatos";
            this.tbpIngresoDatos.Padding = new System.Windows.Forms.Padding(3);
            this.tbpIngresoDatos.Size = new System.Drawing.Size(478, 377);
            this.tbpIngresoDatos.TabIndex = 0;
            this.tbpIngresoDatos.Text = "Ingreso de Datos";
            this.tbpIngresoDatos.UseVisualStyleBackColor = true;
            // 
            // txtCambio
            // 
            this.txtCambio.Location = new System.Drawing.Point(191, 219);
            this.txtCambio.Name = "txtCambio";
            this.txtCambio.Size = new System.Drawing.Size(169, 23);
            this.txtCambio.TabIndex = 8;
            // 
            // txtMarca
            // 
            this.txtMarca.Location = new System.Drawing.Point(191, 178);
            this.txtMarca.Name = "txtMarca";
            this.txtMarca.Size = new System.Drawing.Size(169, 23);
            this.txtMarca.TabIndex = 7;
            // 
            // txtPrecio
            // 
            this.txtPrecio.Location = new System.Drawing.Point(191, 139);
            this.txtPrecio.Name = "txtPrecio";
            this.txtPrecio.Size = new System.Drawing.Size(169, 23);
            this.txtPrecio.TabIndex = 6;
            // 
            // txtModelo
            // 
            this.txtModelo.Location = new System.Drawing.Point(191, 96);
            this.txtModelo.Name = "txtModelo";
            this.txtModelo.Size = new System.Drawing.Size(169, 23);
            this.txtModelo.TabIndex = 5;
            // 
            // btGuardarInfo
            // 
            this.btGuardarInfo.Font = new System.Drawing.Font("Yu Gothic UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btGuardarInfo.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btGuardarInfo.Location = new System.Drawing.Point(137, 287);
            this.btGuardarInfo.Name = "btGuardarInfo";
            this.btGuardarInfo.Size = new System.Drawing.Size(223, 44);
            this.btGuardarInfo.TabIndex = 4;
            this.btGuardarInfo.Text = "GUARDAR INFORMACIÓN";
            this.btGuardarInfo.UseVisualStyleBackColor = true;
            this.btGuardarInfo.Click += new System.EventHandler(this.btGuardarInfo_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(66, 225);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(105, 17);
            this.label4.TabIndex = 3;
            this.label4.Text = "Tipo de cambio";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(66, 184);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "Marca";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(66, 139);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "Precio";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(66, 102);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Modelo";
            // 
            // tbpDatosAuto
            // 
            this.tbpDatosAuto.Controls.Add(this.btCambiarDisp);
            this.tbpDatosAuto.Controls.Add(this.btAplicar);
            this.tbpDatosAuto.Controls.Add(this.textBox1);
            this.tbpDatosAuto.Controls.Add(this.txtDescuento);
            this.tbpDatosAuto.Controls.Add(this.label5);
            this.tbpDatosAuto.Location = new System.Drawing.Point(4, 26);
            this.tbpDatosAuto.Name = "tbpDatosAuto";
            this.tbpDatosAuto.Padding = new System.Windows.Forms.Padding(3);
            this.tbpDatosAuto.Size = new System.Drawing.Size(478, 377);
            this.tbpDatosAuto.TabIndex = 1;
            this.tbpDatosAuto.Text = "Datos Automóvil";
            this.tbpDatosAuto.UseVisualStyleBackColor = true;
            // 
            // btCambiarDisp
            // 
            this.btCambiarDisp.Font = new System.Drawing.Font("Yu Gothic UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btCambiarDisp.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btCambiarDisp.Location = new System.Drawing.Point(70, 327);
            this.btCambiarDisp.Name = "btCambiarDisp";
            this.btCambiarDisp.Size = new System.Drawing.Size(342, 44);
            this.btCambiarDisp.TabIndex = 12;
            this.btCambiarDisp.Text = "CAMBIAR DISPONIBILIDAD";
            this.btCambiarDisp.UseVisualStyleBackColor = true;
            // 
            // btAplicar
            // 
            this.btAplicar.Font = new System.Drawing.Font("Yu Gothic UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btAplicar.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btAplicar.Location = new System.Drawing.Point(329, 40);
            this.btAplicar.Name = "btAplicar";
            this.btAplicar.Size = new System.Drawing.Size(94, 39);
            this.btAplicar.TabIndex = 12;
            this.btAplicar.Text = "Aplicar";
            this.btAplicar.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(70, 104);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox1.Size = new System.Drawing.Size(342, 208);
            this.textBox1.TabIndex = 2;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txtDescuento
            // 
            this.txtDescuento.Location = new System.Drawing.Point(28, 56);
            this.txtDescuento.Name = "txtDescuento";
            this.txtDescuento.Size = new System.Drawing.Size(136, 23);
            this.txtDescuento.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Yu Gothic UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(23, 24);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(104, 28);
            this.label5.TabIndex = 0;
            this.label5.Text = "Descuento";
            // 
            // btLimpiar
            // 
            this.btLimpiar.Font = new System.Drawing.Font("Yu Gothic UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btLimpiar.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btLimpiar.Location = new System.Drawing.Point(683, 377);
            this.btLimpiar.Name = "btLimpiar";
            this.btLimpiar.Size = new System.Drawing.Size(94, 39);
            this.btLimpiar.TabIndex = 9;
            this.btLimpiar.Text = "Limpiar";
            this.btLimpiar.UseVisualStyleBackColor = true;
            this.btLimpiar.Click += new System.EventHandler(this.btLimpiar_Click);
            // 
            // btSalir
            // 
            this.btSalir.Font = new System.Drawing.Font("Yu Gothic UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btSalir.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btSalir.Location = new System.Drawing.Point(683, 442);
            this.btSalir.Name = "btSalir";
            this.btSalir.Size = new System.Drawing.Size(94, 39);
            this.btSalir.TabIndex = 10;
            this.btSalir.Text = "Salir";
            this.btSalir.UseVisualStyleBackColor = true;
            this.btSalir.Click += new System.EventHandler(this.btSalir_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(889, 592);
            this.Controls.Add(this.btSalir);
            this.Controls.Add(this.btLimpiar);
            this.Controls.Add(this.tb1);
            this.Controls.Add(this.lbTitulo);
            this.Name = "Form1";
            this.Text = "LABORATORIO 9";
            this.tb1.ResumeLayout(false);
            this.tbpIngresoDatos.ResumeLayout(false);
            this.tbpIngresoDatos.PerformLayout();
            this.tbpDatosAuto.ResumeLayout(false);
            this.tbpDatosAuto.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbTitulo;
        private System.Windows.Forms.TabControl tb1;
        private System.Windows.Forms.TabPage tbpIngresoDatos;
        private System.Windows.Forms.TextBox txtCambio;
        private System.Windows.Forms.TextBox txtMarca;
        private System.Windows.Forms.TextBox txtPrecio;
        private System.Windows.Forms.TextBox txtModelo;
        private System.Windows.Forms.Button btGuardarInfo;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabPage tbpDatosAuto;
        private System.Windows.Forms.Button btCambiarDisp;
        private System.Windows.Forms.Button btAplicar;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox txtDescuento;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btLimpiar;
        private System.Windows.Forms.Button btSalir;
    }
}

