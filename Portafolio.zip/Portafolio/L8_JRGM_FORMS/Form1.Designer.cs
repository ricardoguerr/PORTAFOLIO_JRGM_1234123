﻿namespace L8_JRGM_FORMS
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.GPBseleccion = new System.Windows.Forms.GroupBox();
            this.CMBopcion = new System.Windows.Forms.ComboBox();
            this.btSeleccionar = new System.Windows.Forms.Button();
            this.TBCPestañas = new System.Windows.Forms.TabControl();
            this.TBPSum = new System.Windows.Forms.TabPage();
            this.lblResultado = new System.Windows.Forms.Label();
            this.txtNumero = new System.Windows.Forms.TextBox();
            this.lblNumero = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.TBPtablas = new System.Windows.Forms.TabPage();
            this.txtNumTABLAS = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.TBPnumperfecto = new System.Windows.Forms.TabPage();
            this.txtNumperfecto = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblNumperfecto = new System.Windows.Forms.Label();
            this.lbxTabla = new System.Windows.Forms.ListBox();
            this.GPBseleccion.SuspendLayout();
            this.TBCPestañas.SuspendLayout();
            this.TBPSum.SuspendLayout();
            this.TBPtablas.SuspendLayout();
            this.TBPnumperfecto.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Yu Gothic UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(369, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(180, 28);
            this.label1.TabIndex = 0;
            this.label1.Text = "LABORATORIO #8 ";
            // 
            // GPBseleccion
            // 
            this.GPBseleccion.Controls.Add(this.CMBopcion);
            this.GPBseleccion.Font = new System.Drawing.Font("Yu Gothic UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GPBseleccion.Location = new System.Drawing.Point(53, 70);
            this.GPBseleccion.Name = "GPBseleccion";
            this.GPBseleccion.Size = new System.Drawing.Size(286, 126);
            this.GPBseleccion.TabIndex = 1;
            this.GPBseleccion.TabStop = false;
            this.GPBseleccion.Text = "Selección";
            // 
            // CMBopcion
            // 
            this.CMBopcion.FormattingEnabled = true;
            this.CMBopcion.Items.AddRange(new object[] {
            "Sumatoria",
            "Tabla de multiplicar",
            "Número perfecto"});
            this.CMBopcion.Location = new System.Drawing.Point(47, 60);
            this.CMBopcion.Name = "CMBopcion";
            this.CMBopcion.Size = new System.Drawing.Size(182, 31);
            this.CMBopcion.TabIndex = 0;
            this.CMBopcion.SelectedIndexChanged += new System.EventHandler(this.CMBopcion_SelectedIndexChanged);
            // 
            // btSeleccionar
            // 
            this.btSeleccionar.Font = new System.Drawing.Font("Yu Gothic UI Semibold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btSeleccionar.Location = new System.Drawing.Point(130, 238);
            this.btSeleccionar.Name = "btSeleccionar";
            this.btSeleccionar.Size = new System.Drawing.Size(123, 34);
            this.btSeleccionar.TabIndex = 2;
            this.btSeleccionar.Text = "Seleccionar";
            this.btSeleccionar.UseVisualStyleBackColor = true;
            this.btSeleccionar.Click += new System.EventHandler(this.btSeleccionar_Click);
            // 
            // TBCPestañas
            // 
            this.TBCPestañas.Controls.Add(this.TBPSum);
            this.TBCPestañas.Controls.Add(this.TBPtablas);
            this.TBCPestañas.Controls.Add(this.TBPnumperfecto);
            this.TBCPestañas.Location = new System.Drawing.Point(421, 70);
            this.TBCPestañas.Name = "TBCPestañas";
            this.TBCPestañas.SelectedIndex = 0;
            this.TBCPestañas.Size = new System.Drawing.Size(458, 368);
            this.TBCPestañas.TabIndex = 3;
            this.TBCPestañas.Visible = false;
            // 
            // TBPSum
            // 
            this.TBPSum.Controls.Add(this.label3);
            this.TBPSum.Controls.Add(this.lblResultado);
            this.TBPSum.Controls.Add(this.txtNumero);
            this.TBPSum.Controls.Add(this.lblNumero);
            this.TBPSum.Controls.Add(this.label4);
            this.TBPSum.Location = new System.Drawing.Point(4, 25);
            this.TBPSum.Name = "TBPSum";
            this.TBPSum.Padding = new System.Windows.Forms.Padding(3);
            this.TBPSum.Size = new System.Drawing.Size(450, 339);
            this.TBPSum.TabIndex = 0;
            this.TBPSum.Text = "Sumatoria";
            this.TBPSum.UseVisualStyleBackColor = true;
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Font = new System.Drawing.Font("Yu Gothic UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultado.Location = new System.Drawing.Point(165, 161);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(0, 23);
            this.lblResultado.TabIndex = 6;
            // 
            // txtNumero
            // 
            this.txtNumero.Location = new System.Drawing.Point(169, 45);
            this.txtNumero.Name = "txtNumero";
            this.txtNumero.Size = new System.Drawing.Size(68, 22);
            this.txtNumero.TabIndex = 5;
            // 
            // lblNumero
            // 
            this.lblNumero.AutoSize = true;
            this.lblNumero.Font = new System.Drawing.Font("Yu Gothic UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumero.Location = new System.Drawing.Point(7, 43);
            this.lblNumero.Name = "lblNumero";
            this.lblNumero.Size = new System.Drawing.Size(0, 23);
            this.lblNumero.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Yu Gothic UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(7, 161);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 23);
            this.label4.TabIndex = 2;
            // 
            // TBPtablas
            // 
            this.TBPtablas.Controls.Add(this.lbxTabla);
            this.TBPtablas.Controls.Add(this.txtNumTABLAS);
            this.TBPtablas.Controls.Add(this.label5);
            this.TBPtablas.Location = new System.Drawing.Point(4, 25);
            this.TBPtablas.Name = "TBPtablas";
            this.TBPtablas.Padding = new System.Windows.Forms.Padding(3);
            this.TBPtablas.Size = new System.Drawing.Size(450, 339);
            this.TBPtablas.TabIndex = 1;
            this.TBPtablas.Text = "Tablas de multiplicar";
            this.TBPtablas.UseVisualStyleBackColor = true;
            // 
            // txtNumTABLAS
            // 
            this.txtNumTABLAS.Location = new System.Drawing.Point(168, 45);
            this.txtNumTABLAS.Name = "txtNumTABLAS";
            this.txtNumTABLAS.Size = new System.Drawing.Size(68, 22);
            this.txtNumTABLAS.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Yu Gothic UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(6, 43);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(156, 23);
            this.label5.TabIndex = 6;
            this.label5.Text = "Ingrese un número";
            // 
            // TBPnumperfecto
            // 
            this.TBPnumperfecto.Controls.Add(this.lblNumperfecto);
            this.TBPnumperfecto.Controls.Add(this.txtNumperfecto);
            this.TBPnumperfecto.Controls.Add(this.label2);
            this.TBPnumperfecto.Location = new System.Drawing.Point(4, 25);
            this.TBPnumperfecto.Name = "TBPnumperfecto";
            this.TBPnumperfecto.Padding = new System.Windows.Forms.Padding(3);
            this.TBPnumperfecto.Size = new System.Drawing.Size(450, 339);
            this.TBPnumperfecto.TabIndex = 2;
            this.TBPnumperfecto.Text = "Número perfecto";
            this.TBPnumperfecto.UseVisualStyleBackColor = true;
            // 
            // txtNumperfecto
            // 
            this.txtNumperfecto.Location = new System.Drawing.Point(168, 45);
            this.txtNumperfecto.Name = "txtNumperfecto";
            this.txtNumperfecto.Size = new System.Drawing.Size(68, 22);
            this.txtNumperfecto.TabIndex = 9;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Yu Gothic UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(6, 43);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(156, 23);
            this.label2.TabIndex = 8;
            this.label2.Text = "Ingrese un número";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Yu Gothic UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(6, 43);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(156, 23);
            this.label3.TabIndex = 7;
            this.label3.Text = "Ingrese un número";
            // 
            // lblNumperfecto
            // 
            this.lblNumperfecto.AutoSize = true;
            this.lblNumperfecto.Location = new System.Drawing.Point(10, 160);
            this.lblNumperfecto.Name = "lblNumperfecto";
            this.lblNumperfecto.Size = new System.Drawing.Size(0, 16);
            this.lblNumperfecto.TabIndex = 10;
            // 
            // lbxTabla
            // 
            this.lbxTabla.FormattingEnabled = true;
            this.lbxTabla.ItemHeight = 16;
            this.lbxTabla.Location = new System.Drawing.Point(10, 104);
            this.lbxTabla.Name = "lbxTabla";
            this.lbxTabla.Size = new System.Drawing.Size(226, 132);
            this.lbxTabla.TabIndex = 8;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(912, 450);
            this.Controls.Add(this.TBCPestañas);
            this.Controls.Add(this.btSeleccionar);
            this.Controls.Add(this.GPBseleccion);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Laboratorio 8";
            this.GPBseleccion.ResumeLayout(false);
            this.TBCPestañas.ResumeLayout(false);
            this.TBPSum.ResumeLayout(false);
            this.TBPSum.PerformLayout();
            this.TBPtablas.ResumeLayout(false);
            this.TBPtablas.PerformLayout();
            this.TBPnumperfecto.ResumeLayout(false);
            this.TBPnumperfecto.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox GPBseleccion;
        private System.Windows.Forms.ComboBox CMBopcion;
        private System.Windows.Forms.Button btSeleccionar;
        private System.Windows.Forms.TabControl TBCPestañas;
        private System.Windows.Forms.TabPage TBPtablas;
        private System.Windows.Forms.TabPage TBPnumperfecto;
        private System.Windows.Forms.TextBox txtNumTABLAS;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtNumperfecto;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TabPage TBPSum;
        private System.Windows.Forms.Label lblResultado;
        private System.Windows.Forms.TextBox txtNumero;
        private System.Windows.Forms.Label lblNumero;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblNumperfecto;
        private System.Windows.Forms.ListBox lbxTabla;
    }
}

