﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using static System.Net.Mime.MediaTypeNames;

namespace L8_JRGM_FORMS
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        

        private void CMBopcion_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (CMBopcion.SelectedIndex)
            {
                case 0:
                    MessageBox.Show("Sumatoria");
                    TBCPestañas.Visible = true;
                    TBCPestañas.SelectedTab = TBPSum;
                    break;
                case 1:
                    MessageBox.Show("Tablas de multiplicar");
                    TBCPestañas.Visible = true;
                    TBCPestañas.SelectedTab = TBPtablas;
                    break;
                case 2:
                    MessageBox.Show("Número perfecto");
                    TBCPestañas.Visible = true;
                    TBCPestañas.SelectedTab = TBPnumperfecto;
                    break;  
            }
        }

        private void btSeleccionar_Click(object sender, EventArgs e)
        {
            int suma = 0;
            int i = 1;
            

            switch (TBCPestañas.SelectedIndex)
            {
                case 0:
                    TBCPestañas.SelectedTab = TBPSum;
                    int n = int.Parse(txtNumero.Text);
                    do
                    {
                        suma = suma + i;
                        i++;
                    } while (i <= n);
                    int resultado = suma;
                    lblResultado.Text = resultado.ToString();

                    break;
                case 1:                  
                    TBCPestañas.SelectedTab = TBPtablas;
                    n = int.Parse(txtNumTABLAS.Text);

                    for (i = 1; i <= 10; i++)
                    {
                        int mult = i * n;
                        lbxTabla.Items.Add (i + " * " + n + " = " + mult);
                    }

                    break;
                case 2:              
                    TBCPestañas.SelectedTab = TBPnumperfecto;
                    n = int.Parse(txtNumperfecto.Text);

                    if (n > 0)
                    {
                        for (i = 1; i < n; i++)
                        {
                            if (n % i == 0)
                            {
                                suma = suma + i;
                            }
                        }
                        if (suma == n)
                        {
                            lblNumperfecto.Text = (n + " es un número perfecto.");
                        }
                        else
                        {
                            lblNumperfecto.Text = (n + " no es un número perfecto.");
                        }
                    }
                    else
                    {
                        lblNumperfecto.Text = ("Ingrese un número valido.");
                    }
                    break;
            }   
        }
    }
}
