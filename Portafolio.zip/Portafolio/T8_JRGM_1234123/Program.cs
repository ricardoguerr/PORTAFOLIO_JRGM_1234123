﻿using System;

internal class Program
{
    private static void Main(string[] args)
    {
        string opcion;
        int suma = 0;
        int i = 1;
        Console.WriteLine("----- LABORATORIO 8 -----");
        Console.WriteLine("ingrese una opción:\n");
        Console.WriteLine("a. Sumatoria");
        Console.WriteLine("b. Tablas de multiplicar");
        Console.WriteLine("c. Número Perfecto");
        opcion = Console.ReadLine();
        opcion.ToLower();
        switch (opcion)
        {
            case "a":
                Console.Clear();
                Console.WriteLine("----- LABORATORIO 8 -----");
                Console.WriteLine("----- SUMATORIA -----");
                Console.Write("\nIngrese un número: "); int n = Convert.ToInt32(Console.ReadLine());
                do
                {
                    suma = suma + i;
                    i++;
                } while (i <= n);

                Console.WriteLine("La suma es: " + suma);
                break;
            case "b":
                Console.Clear();
                Console.WriteLine("----- LABORATORIO 8 -----");
                Console.WriteLine("----- TABLAS DE MULTIPLICAR -----");
                Console.Write("\nIngrese un número: "); n = Convert.ToInt32(Console.ReadLine());
                for ( i = 1; i <= 10; i++)
                {
                    int mult = i * n;
                    Console.WriteLine(i + " * " + n + " = " + mult);
                }
                break;
            case "c":
                Console.Clear();
                Console.WriteLine("----- LABORATORIO 8 -----");
                Console.WriteLine("----- NÚMERO PERFECTO ------");
                Console.Write("\nIngrese un número: "); n = Convert.ToInt32(Console.ReadLine());
                if (n > 0)
                {
                    for( i = 1; i < n; i++)
                    {
                        if( n % i == 0)
                        {
                            suma = suma +  i;
                        }
                    }
                    if (suma == n)
                    {
                        Console.WriteLine(n + " es un número perfecto.");
                    }
                    else
                    {
                        Console.WriteLine(n + " no es un número perfecto.");
                    }
                }
                else
                {
                    Console.WriteLine("Ingrese un número valido");
                }
                break;
        }
    }
}