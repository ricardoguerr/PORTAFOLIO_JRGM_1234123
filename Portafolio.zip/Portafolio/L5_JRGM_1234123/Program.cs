﻿internal class Program
{
    private static void Main(string[] args)
    {
        goto Ejercicio2;
        Console.WriteLine("----- EJERCICIO 1 -----");
        int n1 = 0;
        int dia = 0;
        string numstring = "1287543";
        
        Console.Write("\nIngresar el primer número: ");
  

        bool canConvert = int.TryParse(Console.ReadLine(), out n1);
        if(canConvert == true )
        {
 

            if (n1 > 0)
            {
                Console.WriteLine("El número es positivo");
            }
            else if (n1 < 0)
            {
                Console.WriteLine("El número es negativo");
            }
            else
            {
                Console.WriteLine("El número es cero");
            }
        }
        else
        {
            Console.WriteLine("Usted ingreso una letra");
        }

    Ejercicio2:

        Console.WriteLine("----- EJERCICIO 2 -----");
        Console.Write("\nIngrese el número del día: ");
        dia = Convert.ToInt32(Console.ReadLine());

        switch(dia)
        {
            case 1: Console.WriteLine("Dia: Lunes");
                break;
            case 2:
                Console.WriteLine("Dia: Martes");
                break;
            case 3:
                Console.WriteLine("Dia: Miercoles");
                break;
            case 4:
                Console.WriteLine("Dia: Jueves");
                break;
            case 5:
                Console.WriteLine("Dia: Viernes");
                break;
            case 6:
                Console.WriteLine("Dia: Sábado");
                break;
            case 7:
                Console.WriteLine("Dia: Domingo");
                break;
        }
    }
}